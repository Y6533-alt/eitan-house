import { engagements, film, img, services, work } from "../shared/content.js";

const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
const $ = (id) => document.getElementById(id);

/* ---------------------------------------------------------------- */
/* Scroll film: scroll position drives video time                   */
/* ---------------------------------------------------------------- */

const filmSection = $("film");
const video = $("filmVideo");
const poster = $("filmPoster");
const bar = $("filmBar");
const chapters = [...document.querySelectorAll(".chapter")];

function filmProgress() {
  const r = filmSection.getBoundingClientRect();
  const span = Math.max(r.height - innerHeight, 1);
  return Math.min(Math.max(-r.top / span, 0), 1);
}

if (!reduced) {
  const src = innerWidth < 760 ? film.mobile : film.desktop;
  // Load the whole clip into memory so seeking is instant in both directions.
  fetch(src)
    .then((r) => r.blob())
    .then((b) => {
      video.src = URL.createObjectURL(b);
    })
    .catch(() => {
      video.src = src;
    });

  video.addEventListener("loadeddata", () => {
    video.classList.add("is-ready");
    poster.classList.add("is-hidden");
  });

  let current = 0;
  let seeking = false;
  video.addEventListener("seeked", () => (seeking = false));

  const tick = () => {
    const p = filmProgress();
    bar.style.transform = `scaleX(${p})`;
    if (video.duration) {
      const target = p * (video.duration - 0.05);
      current += (target - current) * 0.18;
      if (!seeking && Math.abs(video.currentTime - current) > 0.01) {
        seeking = true;
        video.currentTime = current;
      }
    }
    requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);

  // iOS needs a gesture before it decodes frames.
  addEventListener("touchstart", () => video.play().then(() => video.pause()).catch(() => {}), { once: true });
}

/* ---------------------------------------------------------------- */
/* 3D ring of work                                                    */
/* ---------------------------------------------------------------- */

const ringSection = $("work");
const ring = $("ring");
const count = work.length;
const step = 360 / count;
$("ringCount").textContent = String(count).padStart(2, "0");

work.forEach((w, i) => {
  const b = document.createElement("button");
  b.type = "button";
  b.className = "ring__card";
  b.style.setProperty("--angle", `${i * step}deg`);
  b.setAttribute("aria-label", `Open ${w.name}, ${w.category}`);
  b.innerHTML = `<img src="${img(w.cover, 1200)}" alt="" loading="lazy" draggable="false">`;
  b.addEventListener("click", () => {
    if (!moved) openViewer(w);
  });
  ring.appendChild(b);
});
const cards = [...ring.children];

let drag = 0;
let dragVel = 0;
let angle = 0;
let active = -1;
let pointerX = null;
let moved = false;

function layoutRing() {
  const w = cards[0].offsetWidth || 260;
  const radius = Math.round(w / 2 / Math.tan(Math.PI / count) + w * 0.18);
  ring.style.setProperty("--radius", `${radius}px`);
}

function setActive(i) {
  active = i;
  cards.forEach((c, j) => c.toggleAttribute("data-active", j === i));
  $("ringNum").textContent = String(i + 1).padStart(2, "0");
  $("ringName").textContent = work[i].name;
  $("ringCat").textContent = work[i].category;
}

function ringTick() {
  const r = ringSection.getBoundingClientRect();
  const span = Math.max(r.height - innerHeight, 1);
  const p = Math.min(Math.max(-r.top / span, 0), 1);
  if (pointerX === null) {
    drag += dragVel;
    dragVel *= 0.92;
  }
  const target = -p * (360 - step) + drag;
  angle += reduced ? target - angle : (target - angle) * 0.12;
  ring.style.transform = `translateZ(calc(var(--radius) * -1)) rotateY(${angle}deg)`;
  const idx = ((Math.round(-angle / step) % count) + count) % count;
  if (idx !== active) setActive(idx);
  requestAnimationFrame(ringTick);
}

ring.addEventListener("pointerdown", (e) => {
  pointerX = e.clientX;
  moved = false;
});
addEventListener("pointermove", (e) => {
  if (pointerX === null) return;
  const dx = e.clientX - pointerX;
  if (Math.abs(dx) > 2) moved = true;
  pointerX = e.clientX;
  drag += dx * 0.25;
  dragVel = dx * 0.25;
});
addEventListener("pointerup", () => (pointerX = null));
addEventListener("resize", layoutRing);
$("ringOpen").addEventListener("click", () => openViewer(work[active]));

layoutRing();
setActive(0);
requestAnimationFrame(ringTick);

/* ---------------------------------------------------------------- */
/* Services with depth tilt                                          */
/* ---------------------------------------------------------------- */

$("serviceCards").innerHTML = services
  .map(
    (s, i) => `
  <article class="tilt">
    <div class="tilt__body">
      <img class="tilt__img" src="${img(s.cover, 1600)}" alt="" loading="lazy">
      <div class="tilt__glare" aria-hidden="true"></div>
      <span class="tilt__index" aria-hidden="true">${String(i + 1).padStart(2, "0")}</span>
      <div class="tilt__copy">
        <h3>${s.name}</h3>
        <p>${s.detail}</p>
      </div>
    </div>
  </article>`,
  )
  .join("");

if (!reduced) {
  document.querySelectorAll(".tilt").forEach((el) => {
    el.addEventListener("pointermove", (e) => {
      const r = el.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width - 0.5;
      const y = (e.clientY - r.top) / r.height - 0.5;
      el.style.setProperty("--rx", `${(-y * 10).toFixed(2)}deg`);
      el.style.setProperty("--ry", `${(x * 14).toFixed(2)}deg`);
      el.style.setProperty("--gx", `${(x + 0.5) * 100}%`);
      el.style.setProperty("--gy", `${(y + 0.5) * 100}%`);
    });
    el.addEventListener("pointerleave", () => {
      el.style.setProperty("--rx", "0deg");
      el.style.setProperty("--ry", "0deg");
    });
  });
}

/* ---------------------------------------------------------------- */
/* Engagement models                                                  */
/* ---------------------------------------------------------------- */

$("plans").innerHTML = engagements
  .map(
    (e) => `
  <article class="plan plan--${e.id}">
    <p class="plan__tag">${e.tag}</p>
    <h3>${e.name}</h3>
    <p>${e.body}</p>
    <ul>${e.points.map((p) => `<li>${p}</li>`).join("")}</ul>
  </article>`,
  )
  .join("");

/* ---------------------------------------------------------------- */
/* Viewer: full resolution (up to 3840px) gallery                    */
/* ---------------------------------------------------------------- */

const viewer = $("viewer");
let lastFocus = null;

function openViewer(w) {
  lastFocus = document.activeElement;
  $("viewerCat").textContent = w.category;
  $("viewerTitle").textContent = w.name;
  $("viewerStrip").innerHTML = w.images
    .map((id) => `<img class="viewer__media" src="${img(id, 3840)}" alt="${w.name}" loading="lazy">`)
    .join("");
  viewer.hidden = false;
  document.body.style.overflow = "hidden";
  $("viewerClose").focus();
}

function closeViewer() {
  viewer.hidden = true;
  document.body.style.overflow = "";
  lastFocus?.focus();
}

$("viewerClose").addEventListener("click", closeViewer);
addEventListener("keydown", (e) => {
  if (e.key === "Escape" && !viewer.hidden) closeViewer();
});
